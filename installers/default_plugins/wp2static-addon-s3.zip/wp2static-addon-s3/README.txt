=== Plugin Name ===
Contributors: leonstafford
Tags: wp2static,s3,static
Requires at least: 3.2
Tested up to: 5.4
Stable tag: 1.0-alpha-006
License: Unlicense
License URI: http://unlicense.org

Adds AWS S3 as a deployment option for WP2Static.

== Description ==

Take advantage of the S3 and optionally CloudFront to host your WordPress
 powered static website.

== Installation ==

Upload the ZIP to your WordPress plugins page within your dashboard.

Activate the plugin, then navigate to your WP2Static main plugin page to see
 the new deployment option available.

== Changelog ==

= 1.1 =

First release
