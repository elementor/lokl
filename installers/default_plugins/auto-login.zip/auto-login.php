<?php
/*
Plugin Name: Auto Login
Plugin URI: https://github.com/lokl-dev/auto-login
Description: Auto login admin user for local dev sites
Version: 0.5
Author: Leon Stafford
Author URI: https://ljs.dev
License: The Unlicense
*/

add_action( 'init', 'loklautologin' );

function loklautologin() {
    // logout if user-agent is one of of the SSGs
    if( 
        ( strpos( $user_agent, 'WP2Static') !== false ) ||
        ( strpos( $user_agent, 'StaticHTMLOutput') !== false )
    ) {
        // logout if logged in
        if ( is_user_logged_in() == TRUE ) {
            wp_logout();
        }

        return;
    }

    // if not logged in, login as admin
    if ( is_user_logged_in() == FALSE ) {
        $user_agent = $_SERVER['HTTP_USER_AGENT']; 
        $user_login = 'admin'; 
        $user = get_userdatabylogin($user_login);
        $user_id = $user->ID; 
        wp_set_current_user($user_id, $user_login);
        wp_set_auth_cookie($user_id); 
        do_action('wp_login', $user_login); 
    }
}
