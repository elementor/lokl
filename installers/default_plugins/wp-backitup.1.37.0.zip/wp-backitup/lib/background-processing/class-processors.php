<?php

/**
 * Describes task processors
 */
class Processors
{
    const CLEANUP           = 'cleanup';
    const FILE_CLEANUP      = 'file_cleanup';
    const DIRECTORY_CLEANUP = 'directory_cleanup';
    const DB_CLEANUP        = 'db_cleanup';
}