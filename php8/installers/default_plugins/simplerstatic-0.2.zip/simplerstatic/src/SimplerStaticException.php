<?php

namespace SimplerStatic;

use Exception;

class SimplerStaticException extends Exception {
}

