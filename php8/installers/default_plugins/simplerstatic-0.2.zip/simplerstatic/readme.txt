=== Simpler Static ===
Contributors: leonstafford
Tags: html, static website generator, static site, secure, fast
Requires at least: 4.0
Tested up to: 5.4.1
Stable tag: 0.2
License:           The Unlicense
License URI:       https://unlicense.org

A simple WordPress static site generator

== Description ==

Simpler Static is based off the long dormant Simply Static plugin.

= Security =

Run on your local computer or on a non-public webserver for best security.

= Performance =



= Other Similar Plugins =

In the event that Simpler Static doesn't meet your needs, give this plugin a try:

- [Static HTML Output](https://wordpress.org/plugins/static-html-output-plugin/)
- [WP2Static](https://wp2static.com)
- [Simply Static](https://wordpress.org/plugins/simply-static)

== Installation ==

Download Zip installer and upload via WordPress > Plugins > Add new

== Frequently Asked Questions ==

= I have questions =

Please visit the [official homepage](https://simplerstatic.com).

== Changelog ==

= 0.2, May 17, 2020 =

* Code tidy-up, static analysis, minor tweaks

= 0.1, May 16, 2020 =

* First new build, based off fork of SimplyStatic

